function soma (numeroA, numeroB)
{
    return numeroA+numeroB;
}